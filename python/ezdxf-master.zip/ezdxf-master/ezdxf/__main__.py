# Purpose: run ezdxf tools
# Created: 20.05.13
# Copyright (C) 2013, Manfred Moitzi
# License: MIT License
print("""
Available modules to run:

ezdxf.pp FILENAME
  ... pretty print DXF tag structure of FILENAME as HTML file
""")


