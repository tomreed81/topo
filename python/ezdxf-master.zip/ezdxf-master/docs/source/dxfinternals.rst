DXF Internals
=============

.. toctree::
   :maxdepth: 1

   dxfinternals/fileencoding
   dxfinternals/filestructure


