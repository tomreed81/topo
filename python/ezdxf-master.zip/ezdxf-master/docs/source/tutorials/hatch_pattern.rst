.. _tut_hatch_pattern:

Tutorial for Hatch Pattern Definition
=====================================

TODO

